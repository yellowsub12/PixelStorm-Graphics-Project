Infinite City

40040127 - Anas Peerzada
40032669 - Kevin Ve
40133493 - Samaninder Singh
40111059 - Ali Turkman
40007224 - Ye Tun

Controls
=====================
	WASD to move
	space to jump
	shift to sprint
	control to move the camera down
	right click to zoom